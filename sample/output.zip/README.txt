SAMPLE INPUT ONLY. Contains 30 reel prompt sets (90 clips), NOT generated videos. Import the DOCX or JSON into the app. Live Veo rendering requires credentials and billing.
